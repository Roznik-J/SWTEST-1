package pset1;

public class C {
    int f;

    public C(int f) {
        this.f = f;
    }

    @Override
    public boolean equals(Object o) {
        // assume this method is implemented for you
	return false;
    }

    @Override
    public int hashCode() {
        // assume this method is implemented for you
	return 1;
    }
}
